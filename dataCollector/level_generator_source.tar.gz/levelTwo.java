/*
levelTwo.java v0.0 12.06.28

Description:
   Creates level two CDF files

v0.0
   -Does nothing, just an empty object for the main program to create

Planned Changes: 
   -Add everything
*/

public class levelTwo{
   
}
